<?php
/**
 * Regions
 *
 * @package    apus-findus
 * @author     ApusTheme <apusthemes@gmail.com >
 * @license    GNU General Public License, version 3
 * @copyright  13/06/2016 ApusTheme
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class ApusFindus_Taxonomy_Regions{

	/**
	 *
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'definition' ), 1 );
	}

	/**
	 *
	 */
	public static function definition() {
		$labels = array(
			'name'              => __( 'Regions', 'apus-findus' ),
			'singular_name'     => __( 'Region', 'apus-findus' ),
			'search_items'      => __( 'Search Regions', 'apus-findus' ),
			'all_items'         => __( 'All Regions', 'apus-findus' ),
			'parent_item'       => __( 'Parent Region', 'apus-findus' ),
			'parent_item_colon' => __( 'Parent Region:', 'apus-findus' ),
			'edit_item'         => __( 'Edit', 'apus-findus' ),
			'update_item'       => __( 'Update', 'apus-findus' ),
			'add_new_item'      => __( 'Add New', 'apus-findus' ),
			'new_item_name'     => __( 'New Region', 'apus-findus' ),
			'menu_name'         => __( 'Regions', 'apus-findus' ),
		);

		register_taxonomy( 'job_listing_region', 'job_listing', array(
			'labels'            => apply_filters( 'apusfindus_taxomony_booking_amenities_labels', $labels ),
			'hierarchical'      => true,
			'query_var'         => 'region',
			'rewrite'           => array( 'slug' => __( 'region', 'apus-findus' ) ),
			'public'            => true,
			'show_ui'           => true,
			'show_in_rest'		=> false
		) );
	}
	
}

ApusFindus_Taxonomy_Regions::init();