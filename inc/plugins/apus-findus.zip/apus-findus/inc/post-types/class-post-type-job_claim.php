<?php
/**
 * claim
 *
 * @package    apus-findus
 * @author     Apusthemes <apusthemes@gmail.com >
 * @license    GNU General Public License, version 3
 * @copyright  2015-2016 Apus Framework
 */
 
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

class ApusFindus_Post_Type_Claim {

  	public static function init() {
    	add_action( 'init', array( __CLASS__, 'register_post_type' ) );

    	add_filter( 'cmb2_meta_boxes', array( __CLASS__, 'metaboxes' ) );
    	add_filter( 'manage_edit-job_claim_columns', array( __CLASS__, 'custom_columns' ) );
		add_action( 'manage_job_claim_posts_custom_column', array( __CLASS__, 'custom_columns_manage' ) );

  	}

  	public static function register_post_type() {
	    $labels = array(
			'name'                  => esc_html__( 'Claim', 'apus-findus' ),
			'singular_name'         => esc_html__( 'Claim', 'apus-findus' ),
			'add_new'               => esc_html__( 'Add New Claim', 'apus-findus' ),
			'add_new_item'          => esc_html__( 'Add New Claim', 'apus-findus' ),
			'edit_item'             => esc_html__( 'Edit Claim', 'apus-findus' ),
			'new_item'              => esc_html__( 'New Claim', 'apus-findus' ),
			'all_items'             => esc_html__( 'Claims', 'apus-findus' ),
			'view_item'             => esc_html__( 'View Claim', 'apus-findus' ),
			'search_items'          => esc_html__( 'Search Claim', 'apus-findus' ),
			'not_found'             => esc_html__( 'No Claims found', 'apus-findus' ),
			'not_found_in_trash'    => esc_html__( 'No Claims found in Trash', 'apus-findus' ),
			'parent_item_colon'     => '',
			'menu_name'             => esc_html__( 'Claims', 'apus-findus' ),
	    );

	    register_post_type( 'job_claim',
	      	array(
		        'labels'            => apply_filters( 'apus_findus_postype_fields_labels' , $labels ),
		        'supports'          => array( 'title' ),
		        'public'            => true,
		        'has_archive'       => false,
		        'publicly_queryable' => false,
		        'menu_position'     => 52,
		        'show_in_menu'		=> 'edit.php?post_type=job_listing',
	      	)
	    );

  	}
  	
  	public static function metaboxes(array $metaboxes){
		$prefix = 'findus_claim_';
	    
	    $metaboxes[ $prefix . 'settings' ] = array(
			'id'                        => $prefix . 'settings',
			'title'                     => esc_html__( 'Claim Information', 'apus-findus' ),
			'object_types'              => array( 'job_claim' ),
			'context'                   => 'normal',
			'priority'                  => 'high',
			'show_names'                => true,
			'fields'                    => self::metaboxes_fields()
		);

	    return $metaboxes;
	}

	public static function metaboxes_fields() {
		
		$prefix = 'findus_claim_';
		$listings = array();
		if ( is_admin() ) {
			$args = array(
				'post_type' => 'job_listing',
				'posts_per_page' => -1,
				'status' => 'public'
			);
			$loop = new WP_Query($args);

			if ( $loop->have_posts() ) {
				foreach ($loop->posts as $listing) {
					$listings[$listing->ID] = $listing->post_title;
				}
			}
		}
		$fields =  array(
			array(
				'name' => esc_html__( 'Claim For', 'apus-findus' ),
				'id'   => $prefix."claim_for",
				'type' => 'select',
				'options' => $listings
			),
			array(
				'name' => esc_html__( 'Status', 'apus-findus' ),
				'id'   => $prefix."status",
				'type' => 'select',
				'options' => array(
					'pending' => esc_html__( 'Pending', 'apus-findus' ),
					'approved' => esc_html__( 'Approved', 'apus-findus' ),
					'decline' => esc_html__( 'Decline', 'apus-findus' ),
				)
			),
			array(
				'name' => esc_html__( 'Claim Detail', 'apus-findus' ),
				'id'   => $prefix."detail",
				'type' => 'textarea',
			),
			
		);  
		
		return apply_filters( 'apus_findus_postype_fields_metaboxes_fields' , $fields );
	}

	public static function custom_columns($fields) {
		$fields = array(
			'cb' 				=> '<input type="checkbox" />',
			'title' 			=> esc_html__( 'Title', 'apus-findus' ),
			'author' 			=> esc_html__( 'Author', 'apus-findus' ),
			'status' 		=> esc_html__( 'Status', 'apus-findus' ),
			'date' 		=> esc_html__( 'Date', 'apus-findus' ),
		);
		
		return $fields;
	}

	public static function custom_columns_manage( $column ) {
		global $post;
		switch ( $column ) {
			case 'status':
				$status = get_post_meta( get_the_ID(), 'findus_claim_status', true );
				$statuses = array(
					'pending' => esc_html__( 'pending', 'apus-findus' ),
					'approved' => esc_html__( 'Approved', 'apus-findus' ),
					'decline' => esc_html__( 'Decline', 'apus-findus' ),
				);
				echo isset($statuses[$status]) ? $statuses[$status] : '';
				break;
		}
	}
}

ApusFindus_Post_Type_Claim::init();