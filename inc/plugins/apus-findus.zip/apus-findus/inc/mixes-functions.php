<?php
/**
 * functions
 *
 * @package    apus-findus
 * @author     ApusTheme <apusthemes@gmail.com >
 * @license    GNU General Public License, version 3
 * @copyright  13/06/2016 ApusTheme
 */
 
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function apusfindus_get_config($name, $default = '') {
    global $apus_options;
    if ( isset($apus_options[$name]) ) {
        return $apus_options[$name];
    }
    return $default;
}

function apusfindus_removefilter($tag, $args) {
    remove_filter( $tag, $args );
}

function apusfindus_addmetaboxes($fnc) {
    add_action( 'add_meta_boxes', $fnc );
}

function apusfindus_addmetabox($key, $title, $fnc, $textdomain, $position, $priority, $args = null){
    add_meta_box( $key, $title, $fnc, $textdomain, $position, $priority, $args );
}

function apus_wjm_send_mail($to, $subject, $message, $headers){
    return wp_mail( $to, $subject, $message, $headers );
}


function apusfindus_get_default_field_types() {
    
    $fields = apply_filters( 'apusfindus_get_default_field_types', array(
        array(
            'title' => esc_html__('Direct Input', 'apus-findus'),
            'fields' => array(
                'text' => esc_html__('Text', 'apus-findus'),
                'textarea' => esc_html__('Textarea', 'apus-findus'),
                'wp-editor' => esc_html__('WP Editor', 'apus-findus'),
                'date' => esc_html__('Date', 'apus-findus'),
                'number' => esc_html__('Number', 'apus-findus'),
                'url' => esc_html__('Url', 'apus-findus'),
                'email' => esc_html__('Email', 'apus-findus'),
            )
        ),
        array(
            'title' => esc_html__('Choices', 'apus-findus'),
            'fields' => array(
                'select' => esc_html__('Select', 'apus-findus'),
                'multiselect' => esc_html__('Multiselect', 'apus-findus'),
                'checkbox' => esc_html__('Checkbox', 'apus-findus'),
                'radio' => esc_html__('Radio Buttons', 'apus-findus'),
            )
        ),
        array(
            'title' => esc_html__('Form UI', 'apus-findus'),
            'fields' => array(
                'heading' => esc_html__('Heading', 'apus-findus')
            )
        ),
        array(
            'title' => esc_html__('Others', 'apus-findus'),
            'fields' => array(
                'file' => esc_html__('File', 'apus-findus')
            )
        ),
    ));
    
    return $fields;
}

function apusfindus_get_all_field_types() {
    $fields = apusfindus_get_default_field_types();
    $return = array();
    foreach ($fields as $group) {
        foreach ($group['fields'] as $key => $value) {
            $return[] = $key;
        }
    }

    return apply_filters( 'apusfindus_get_all_field_types', $return );
}

function apusfindus_all_types_required_fields() {
    return apply_filters( 'apusfindus-custom-required-fields', array() );
}

function apusfindus_all_types_available_fields() {
    return apply_filters( 'apusfindus-custom-available-fields', array() );
}

function apusfindus_get_custom_fields_data() {
    return apply_filters( 'apusfindus-get-custom-fields-data', get_option('findus_custom_fields_data', array()) );
}


function apusfindus_display_hooks() {
    return apply_filters( 'apusfindus_display_hooks', array() );
}

function apusfindus_icon_picker($value = '', $id = '', $name = '', $class = 'apusfindus-icon-pickerr') {

    $html = "
    <script>
    jQuery(document).ready(function ($) {
        setTimeout(function(){
            var e9_element = $('#icon_picker_".$id."').fontIconPicker({
                theme: 'fip-bootstrap',
                source: all_loaded_icons
            });
        }, 100);
    });
    </script>";

    $html .= '<input type="text" id="icon_picker_' . $id . '" class="' . $class . '" name="' . $name . '" value="' . $value . '">';

    return $html;
}




