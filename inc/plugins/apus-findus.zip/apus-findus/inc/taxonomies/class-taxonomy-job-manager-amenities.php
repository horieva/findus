<?php
/**
 * Amenities
 *
 * @package    apus-findus
 * @author     ApusTheme <apusthemes@gmail.com >
 * @license    GNU General Public License, version 3
 * @copyright  13/06/2016 ApusTheme
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
class ApusFindus_Taxonomy_Amenities{

	/**
	 *
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'definition' ), 1 );
	}

	/**
	 *
	 */
	public static function definition() {
		$labels = array(
			'name'              => __( 'Amenities', 'apus-findus' ),
			'singular_name'     => __( 'Amenity', 'apus-findus' ),
			'search_items'      => __( 'Search Amenities', 'apus-findus' ),
			'all_items'         => __( 'All Amenities', 'apus-findus' ),
			'parent_item'       => __( 'Parent Amenity', 'apus-findus' ),
			'parent_item_colon' => __( 'Parent Amenity:', 'apus-findus' ),
			'edit_item'         => __( 'Edit', 'apus-findus' ),
			'update_item'       => __( 'Update', 'apus-findus' ),
			'add_new_item'      => __( 'Add New', 'apus-findus' ),
			'new_item_name'     => __( 'New Amenity', 'apus-findus' ),
			'menu_name'         => __( 'Amenities', 'apus-findus' ),
		);

		register_taxonomy( 'job_listing_amenity', 'job_listing', array(
			'labels'            => apply_filters( 'apus_findus_taxomony_booking_amenities_labels', $labels ),
			'hierarchical'      => true,
			'query_var'         => 'amenity',
			'rewrite'           => array( 'slug' => __( 'amenity', 'apus-findus' ) ),
			'public'            => true,
			'show_ui'           => true,
			'show_in_rest'		=> true
		) );
	}

}

ApusFindus_Taxonomy_Amenities::init();